var str='Hello World!'
for(var i=0;i<=4;i++){
    document.write(str+'<br>')
}