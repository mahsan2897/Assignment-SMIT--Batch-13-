for(i=1;i<=20;i++){
  document.write(`${i*5},`)  
}