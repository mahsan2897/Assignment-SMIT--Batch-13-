var students=['Ali','Sami','Taha','Inam']
var scores=[28,73,89,90]
document.write(`<table border='' align='center' width='40%'>
  <tr align='center'>
  <td>${students[0]}</td>
  <td>${scores[0]}</td>
  </tr>
  <tr align='center'>
  <td>${students[1]}</td>
  <td>${scores[1]}</td>
  </tr>
  <tr align='center'>
  <td>${students[2]}</td>
  <td>${scores[2]}</td>
  </tr>
  <tr align='center'>
  <td>${students[3]}</td>
  <td>${scores[3]}</td>
  </tr>
  </table>`)