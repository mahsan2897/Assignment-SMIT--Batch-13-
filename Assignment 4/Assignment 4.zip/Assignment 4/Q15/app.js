var arr=[[1,2,3],[4,5,6],[7,8,9]]
for(i=0;i<arr.length;i++){
  var stan=arr[i]
  for(j=0;j<stan.length;j++){
    document.write(stan[j]+' ')
  }
  document.write('<br>')
}