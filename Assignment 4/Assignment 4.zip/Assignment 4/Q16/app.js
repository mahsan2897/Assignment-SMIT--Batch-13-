var num=+prompt('Enter a number')
for(i=num;i>=0;i=i-0.5){
  document.write(i,',')
}