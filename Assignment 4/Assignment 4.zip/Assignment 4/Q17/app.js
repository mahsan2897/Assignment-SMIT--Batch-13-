for(i=0;i<=20;i++){
  if(i%2==0){
    document.write(`${i} is even <br>`)
  }
  else{
    document.write(`${i} is odd <br>`)
  }
}