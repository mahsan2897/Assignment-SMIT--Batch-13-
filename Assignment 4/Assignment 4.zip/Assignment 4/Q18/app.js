var prod=1
for(i=1;i<=7;i=i+2){
  prod=prod*i
}
document.write(`The product of odd integers from 1 to 7 is ${prod}`)