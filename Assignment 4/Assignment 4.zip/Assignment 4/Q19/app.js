var num=+prompt('Enter number of stars')
for(i=num;i>=1;i--){
  for(j=i;j>=1;j--){
    document.write('*')
  }
  document.write('<br>')
}