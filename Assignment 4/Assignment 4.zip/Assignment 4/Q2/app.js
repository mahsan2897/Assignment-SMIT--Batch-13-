for(var i=1;i<=10;i++){
    document.write(i+'<br>')
}