var num=+prompt('Enter number of stars')
for(i=1;i<=num;i++){
  for(j=1;j<=i;j++){
    document.write('*')
  }
  document.write('<br>')
}