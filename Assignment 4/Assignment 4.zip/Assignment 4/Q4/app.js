var arr=['Nokia','Samsung','Apple','Sony','Huawei']
for(var i=0;i<arr.length;i++){
    document.write(arr[i]+'<br>')
}